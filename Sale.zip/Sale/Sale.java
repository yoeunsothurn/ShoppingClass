// Interface for DiscountRate
interface DiscountRate {
    double getServiceDiscountRate(String type);
    double getProductDiscountRate(String type);
}

// Sale class
class Sale implements DiscountRate {
    @Override
    public double getServiceDiscountRate(String type) {
        switch (type) {
            case "Premium":
                return 0.20; // 20% discount
            case "Gold":
                return 0.15; // 15% discount
            case "Silver":
                return 0.10; // 10% discount
            default:
                return 0.00; // 0% discount
        }
    }

    @Override
    public double getProductDiscountRate(String type) {
        switch (type) {
            case "Premium":
            case "Gold":
            case "Silver":
                return 0.10; // 10% discount for all premium, gold, and silver
            default:
                return 0.00; // 0% discount
        }
    }
}

// Customer class
class Customer implements DiscountRate {
    private String type;

    public Customer(String type) {
        this.type = type;
    }

    @Override
    public double getServiceDiscountRate(String type) {
        Sale sale = new Sale();
        return sale.getServiceDiscountRate(type);
    }

    @Override
    public double getProductDiscountRate(String type) {
        Sale sale = new Sale();
        return sale.getProductDiscountRate(type);
    }
}

