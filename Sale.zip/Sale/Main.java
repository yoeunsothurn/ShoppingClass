// Main class for testing
public class Main {
    public static void main(String[] args) {
        Customer premiumCustomer = new Customer("Premium");
        Customer goldCustomer = new Customer("Gold");
        Customer silverCustomer = new Customer("Silver");
        Customer normalCustomer = new Customer("Normal");

        System.out.println("Premium Service Discount Rate: " + premiumCustomer.getServiceDiscountRate("Premium"));
        System.out.println("Gold Service Discount Rate: " + goldCustomer.getServiceDiscountRate("Gold"));
        System.out.println("Silver Service Discount Rate: " + silverCustomer.getServiceDiscountRate("Silver"));
        System.out.println("Normal Service Discount Rate: " + normalCustomer.getServiceDiscountRate("Normal"));

        System.out.println("Premium Product Discount Rate: " + premiumCustomer.getProductDiscountRate("Premium"));
        System.out.println("Gold Product Discount Rate: " + goldCustomer.getProductDiscountRate("Gold"));
        System.out.println("Silver Product Discount Rate: " + silverCustomer.getProductDiscountRate("Silver"));
        System.out.println("Normal Product Discount Rate: " + normalCustomer.getProductDiscountRate("Normal"));
    }
}
